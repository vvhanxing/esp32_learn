# Jello Tab Bar (Animated)

A Pen created on CodePen.io. Original URL: [https://codepen.io/flavio_amaral/pen/xxgYGrR](https://codepen.io/flavio_amaral/pen/xxgYGrR).

Animated Mobile Tab Bar

Credits:
- Design based: https://dribbble.com/shots/10474707-Experimental-UI-animation
- Icons: https://icons.getbootstrap.com
- Colors: https://material.io/resources/color
- Font: https://fonts.google.com/
- Image: https://www.pexels.com/
- Jello Animation: https://animista.net/play/basic