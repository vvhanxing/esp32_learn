# input :not(:placeholder-shown)

A Pen created on CodePen.io. Original URL: [https://codepen.io/avstorm/pen/gKGbxo](https://codepen.io/avstorm/pen/gKGbxo).

Floating Material input with :not(:placeholder-shown)