# Bootstrap image upload preview plugin

A Pen created on CodePen.io. Original URL: [https://codepen.io/shubhamc_007/pen/zNJWPM](https://codepen.io/shubhamc_007/pen/zNJWPM).

JQuery & Bootstrap image upload with advance functionality