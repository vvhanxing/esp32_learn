# Animated Tab Bar

A Pen created on CodePen.io. Original URL: [https://codepen.io/abxlfazl/pen/VwKzaEm](https://codepen.io/abxlfazl/pen/VwKzaEm).

Designed by:  Mauricio Bucardo


 Original image:
https://dribbble.com/shots/5619509-Animated-Tab-Bar

You can use this menu in your projects.
It also works with 100% width and reacts to changing the size of the window :)